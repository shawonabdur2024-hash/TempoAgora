package com.example.tempoagora

import com.example.tempoagora.data.ForecastResponse
import com.example.tempoagora.data.Location
import com.example.tempoagora.data.WarningResponse
import retrofit2.http.GET
import retrofit2.http.Path

interface IpmaApiService {

    @GET("open-data/distrits-islands.json")
    suspend fun getLocations(): Map<String, Location>

    @GET("open-data/forecast/meteorology/cities/daily/{globalIdLocal}.json")
    suspend fun getForecast(@Path("globalIdLocal") id: String): ForecastResponse

    @GET("open-data/forecast/warnings/warnings_www.json")
    suspend fun getWarnings(): WarningResponse
}