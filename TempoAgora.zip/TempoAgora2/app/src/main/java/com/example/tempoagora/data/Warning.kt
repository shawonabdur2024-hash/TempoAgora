package com.example.tempoagora.data

data class WarningResponse(
    val data: List<WarningItem>? = null
)

data class WarningItem(
    val text: String? = null,
    val type: String? = null,           // e.g. "rain", "wind"
    val startTime: String? = null,
    val endTime: String? = null,
    val level: String? = null           // "yellow", "orange", "red"
)