package com.example.tempoagora.data

data class ForecastResponse(
    val owner: Owner? = null,
    val country: String? = null,
    val data: List<DailyForecast>? = null,
    val globalIdLocal: Int? = null
)

data class Owner(
    val name: String? = null,
    val website: String? = null
)

data class DailyForecast(
    val precipitaProb: Int? = null,      // probability of rain %
    val tMin: Int? = null,
    val tMax: Int? = null,
    val predWindDir: String? = null,     // wind direction
    val idWeatherType: Int? = null,      // 1=sunny, 2=clouds, etc.
    val classWindSpeed: Int? = null,
    val dd: String? = null,              // date like "2026-02-22"
    val date: String? = null
)