package com.example.tempoagora

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.tempoagora.data.DailyForecast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class ForecastAdapter(
    private val forecasts: List<DailyForecast>
) : RecyclerView.Adapter<ForecastAdapter.ForecastViewHolder>() {

    class ForecastViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDay: TextView = itemView.findViewById(R.id.tv_day)
        val ivIcon: ImageView = itemView.findViewById(R.id.iv_icon)
        val tvTemp: TextView = itemView.findViewById(R.id.tv_temp)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ForecastViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_forecast_day, parent, false)
        return ForecastViewHolder(view)
    }

    override fun onBindViewHolder(holder: ForecastViewHolder, position: Int) {
        val forecast = forecasts[position]

        // Better weekday name in Portuguese
        val dayText = try {
            val date = LocalDate.parse(forecast.dd ?: "")
            val formatter = DateTimeFormatter.ofPattern("EEE", Locale("pt", "PT"))
            date.format(formatter).replaceFirstChar { it.uppercase() }
        } catch (e: Exception) {
            "Dia ${position + 1}"
        }
        holder.tvDay.text = dayText

        // Temperature
        val tempText = if (forecast.tMin != null && forecast.tMax != null) {
            "${forecast.tMin}° / ${forecast.tMax}°"
        } else {
            "– / –"
        }
        holder.tvTemp.text = tempText

        // Real IPMA icon with debug
        val iconId = forecast.idWeatherType ?: 1
        val iconUrl = "https://api.ipma.pt/images/ico/svg/$iconId.svg"
        Log.d("ForecastAdapter", "Trying to load icon: $iconUrl for day $dayText")

        Glide.with(holder.itemView.context)
            .load(iconUrl)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_close_clear_cancel)
            .into(holder.ivIcon)
    }

    override fun getItemCount(): Int = forecasts.size
}