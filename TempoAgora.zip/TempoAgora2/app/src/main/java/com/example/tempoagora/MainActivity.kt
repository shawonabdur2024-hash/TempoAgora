package com.example.tempoagora

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.tempoagora.data.DailyForecast
import com.example.tempoagora.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fake current weather
        binding.tvLocation.text = "Lisboa"
        binding.tvDate.text = "Hoje, ${getCurrentDateString()}"
        binding.tvTemperature.text = "19°"
        binding.tvDescription.text = "Parcialmente nublado"
        binding.tvMinMax.text = "Máx 23° / Mín 12°"
        binding.tvRainProb.text = "Chuva 10%"

        // Fake 5-day forecast
        val fakeForecasts = listOf(
            DailyForecast(tMin = 12, tMax = 19, dd = "2026-02-23", idWeatherType = 1),
            DailyForecast(tMin = 11, tMax = 17, dd = "2026-02-24", idWeatherType = 3),
            DailyForecast(tMin = 10, tMax = 16, dd = "2026-02-25", idWeatherType = 2),
            DailyForecast(tMin = 9,  tMax = 15, dd = "2026-02-26", idWeatherType = 5),
            DailyForecast(tMin = 8,  tMax = 14, dd = "2026-02-27", idWeatherType = 1)
        )

        val adapter = ForecastAdapter(fakeForecasts)
        binding.recyclerForecast.adapter = adapter
        binding.recyclerForecast.layoutManager =
            androidx.recyclerview.widget.LinearLayoutManager(
                this,
                androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL,
                false
            )

        binding.cardAlert.visibility = android.view.View.GONE
    }

    private fun getCurrentDateString(): String {
        val format = SimpleDateFormat("dd MMM yyyy", Locale("pt", "PT"))
        return format.format(Date())
    }
}