package com.example.tempoagora.data

data class Location(
    val id: String,
    val name: String? = null,
    val local: String? = null,
    val latitude: String? = null,
    val longitude: String? = null
)